const mongoose = require("mongoose");

const transactionSchema = new mongoose.Schema({
  // Core linkage
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  // For deposits/withdrawals
  senderId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  // For internal transfers
  receiverId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },

  // Amount and currency
  amount: { type: Number, required: true },
  senderCurrency: { type: String }, // Only for transfers
  receiverCurrency: { type: String }, // Only for transfers
  currency: { type: String }, // For blockchain tx (BTC, ETH, TRX, USDT-ERC20, etc.)
  convertedAmount: { type: Number },
  fee: { type: Number, default: 0 },

  // Transaction type
  type: {
    type: String,
    enum: ["deposit", "fund", "transfer", "withdraw", "molada-to-molada"],
    required: true,
  },
type: {
    type: String,
    enum: ["deposit", "fund", "transfer", "withdraw", "molada-to-molada"],
    required: true,
  },
  // Method / channel
  method: {
    type: String,
    enum: ["blockchain", "qrcode", "email/phone"],
    default: "email/phone",
  },

  // Status
  status: {
    type: String,
    enum: ["pending", "success", "failed", "completed"],
    default: "pending",
  },

  // On-chain data
  onchainTxHash: { type: String, index: true },
  onchainLogIndex: { type: Number }, // ERC20/TRC20
  utxo: { type: String }, // For BTC
  confirmations: { type: Number, default: 0 },

  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

// Indexes
transactionSchema.index(
  { onchainTxHash: 1, onchainLogIndex: 1 },
  { unique: true, sparse: true }
);
transactionSchema.index({ utxo: 1 }, { unique: true, sparse: true });

// Auto-update updatedAt
transactionSchema.pre("save", function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model("Transaction", transactionSchema);