const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const deviceSchema = new mongoose.Schema(
  {
    deviceId: String,
    ip: String,
    userAgent: String,
    city: String,
    country: String,
    region: String,
    timezone: String,
    loginAt: { type: Date, default: Date.now },
    logoutAt: { type: Date },
    createdAt: { type: Date, default: Date.now },
    warningSent: { type: Boolean, default: false },
  },
  { _id: false }
);

const securityQuestionSchema = new mongoose.Schema(
  {
    questionId: { type: String, required: true },
    answerHash: { type: String, required: true },
  },
  { _id: false }
);

const kycSchema = new mongoose.Schema(
  {
    bvn: { type: String },
    nin: { type: String },
    passport: { type: String }, // file path
    idCard: { type: String }, // file path
    status: {
      type: String,
      enum: ['pending', 'verified', 'rejected'],
      default: 'pending',
    },
    submittedAt: { type: Date },
    verifiedAt: { type: Date },
    rejectedReason: { type: String },
  },
  { _id: false }
);

// --------- USER SCHEMA ----------
const userSchema = new mongoose.Schema(
  {
    fullName: { type: String, required: true },
    address: { type: String, required: true },
    postalCode: { type: String, required: true },
    age: { type: Number, required: true },
    email: { type: String, required: true, unique: true },
    parentEmail: { type: String },
    phone: { type: String, required: true },
    referralCode: { type: String },
    password: { type: String, required: true },

    // Email OTP
    otp: { type: String },
    otpExpires: { type: Date },
    verified: { type: Boolean, default: false },

    virtualAccount: {
      accountNumber: String,
      bankName: String,
    },

    // Wallet
    walletBalance: { type: Number, default: 0 },
    currency: { type: String },

    // Password reset
    resetPasswordToken: { type: String },
    resetPasswordExpires: { type: Date },

    // OTP rate-limit
    otpRequests: { type: Number, default: 0 },
    otpLastRequest: { type: Date },

    country: { type: String },
    lastLogin: { type: Date },

    // Biometric
    fingerprint: { type: String },
    fingerprintEnabled: { type: Boolean, default: false },

    // Transaction PIN
    transactionPin: { type: String },

    // PIN recovery
    pinResetOtp: { type: String },
    pinResetOtpExpires: { type: Date },

    // Security questions
    securityQuestions: [securityQuestionSchema],

    // Devices
    devices: [deviceSchema],

    // KYC
    kyc: kycSchema,
    kycStatus: {
      type: String,
      enum: ['pending', 'approved', 'rejected'],
      default: 'pending'
    },

    // -------- CRYPTO WALLET FIELDS --------
    crypto: {
      evmIndex: { type: Number, default: null },
      btcIndex: { type: Number, default: null },
      trxIndex: { type: Number, default: null },

      bitcoin: { type: String },
    bitcoinPrivateKey: { type: String },
    ethereum: { type: String },
    ethereumPrivateKey: { type: String },
    tron: { type: String },
    tronPrivateKey: { type: String },
    mnemonic: { type: String }
  },

    // -------- BALANCES --------
    balances: {
      eth: { type: Number, default: 0 }, // Ethereum
      btc: { type: Number, default: 0 }, // Bitcoin
      trx: { type: Number, default: 0 }, // TRX
      usdt_trc20: { type: Number, default: 0 }, // USDT TRC20
      usdt_eth: { type: Number, default: 0 }, //USDT ERC20
    }
  },
  { timestamps: true }
);

// --------- AUTO-CREATE CRYPTO FIELD FOR OLD USERS ----------
userSchema.pre('save', function (next) {
  if (!this.crypto) {
    this.crypto = {
      evmIndex: null,
      btcIndex: null,
      trxIndex: null,
      eth: null,
      usdt_eth: null,
      usdt_trc20: null,
      btc: null,
      trx: null,
      trxPrivateKey: null,
    };
  }
  if (!this.balances) {
    this.balances = {
      eth: 0,
      usdt_eth: 0,
      btc: 0,
      trx: 0,
      usdt_trc20: 0,
    };
  }
  next();
});

// Compare PIN
userSchema.methods.comparePin = async function (pin) {
  if (!this.transactionPin) return false;
  return bcrypt.compare(pin, this.transactionPin);
};

module.exports = mongoose.model('User', userSchema);