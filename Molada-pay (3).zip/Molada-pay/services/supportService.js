const { google } = require("googleapis");
const { v4: uuidv4 } = require("uuid");

const CLIENT_ID = process.env.GMAIL_CLIENT_ID;
const CLIENT_SECRET = process.env.GMAIL_CLIENT_SECRET;
const REDIRECT_URI = process.env.GMAIL_REDIRECT_URI;
const REFRESH_TOKEN = process.env.GMAIL_REFRESH_TOKEN;
const SUPPORT_EMAIL = process.env.SUPPORT_EMAIL;

const oAuth2Client = new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET, REDIRECT_URI);
oAuth2Client.setCredentials({ refresh_token: REFRESH_TOKEN });

// --- AI FAQ (very simple rule-based, you can plug in GPT later)
function aiBotAnswer(question) {
  const q = question.toLowerCase();
  if (q.includes("reset password")) return "You can reset your password in Profile > Security.";
  if (q.includes("deposit")) return "You can deposit using blockchain wallets or bank transfer.";
  if (q.includes("withdraw")) return "Withdrawals are processed in 5–30 minutes.";
  return null; // means AI cannot answer
}

/**
 * Send mail to human support
 */
async function sendSupportMail({ userEmail, subject, message, ticketId }) {
  const gmail = google.gmail({ version: "v1", auth: oAuth2Client });

  const rawMessage = Buffer.from(
    `To: ${SUPPORT_EMAIL}\r\n` +
      `From: ${userEmail}\r\n` +
      `Subject: [Ticket ${ticketId}] ${subject}\r\n\r\n` +
      `${message}`
  )
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");

  await gmail.users.messages.send({ userId: "me", requestBody: { raw: rawMessage } });
}

/**
 * Poll Gmail for replies
 */
async function listReplies() {
  const gmail = google.gmail({ version: "v1", auth: oAuth2Client });
  const res = await gmail.users.messages.list({ userId: "me", q: "is:unread" });
  return res.data.messages || [];
}

async function getReply(messageId) {
  const gmail = google.gmail({ version: "v1", auth: oAuth2Client });
  const res = await gmail.users.messages.get({ userId: "me", id: messageId });
  const body = res.data.payload.parts?.[0]?.body?.data;
  if (!body) return "";
  return Buffer.from(body, "base64").toString("utf-8");
}

module.exports = { aiBotAnswer, sendSupportMail, listReplies, getReply };