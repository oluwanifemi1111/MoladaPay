require('dotenv').config({ debug: false });
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const connectDB = require('./config/db');
const transferRoutes = require('./routes/transfer')
const securityRoutes = require('./routes/security');
const webhookRoutes = require('./routes/webhook');
const cardRoutes = require('./routes/card');
const cleanupUnverified = require("./jobs/cleanup");
const cron = require("node-cron");
const { startDepositWatchers } = require("./services/depositWatchers");
const cryptoRoutes = require('./routes/cryptoRoutes');
const billsRoutes = require("./routes/bills");


require("dotenv").config();

startDepositWatchers();
connectDB();
const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: true }));
app.use("/api/bills", billsRoutes);

// Test route
app.get('/', (req, res) => {
  res.send('Molada Pay API running...');
});



// Routes placeholder
app.use('/api/auth', require('./routes/auth'));
app.use('/api/wallet', require('./routes/wallet'));
app.use('/api/security', securityRoutes);
app.use('/api/transfer', transferRoutes);
app.use('/api/deposit', require('./routes/deposit'));
app.use('/api/webhook', require('./routes/webhook'));
app.use('/api/wallet', require('./routes/wallet'));
app.use('/api/payment', cardRoutes);
app.use("/api/crypto", require("./routes/cryptoRoutes"));
const PORT = process.env.BACKEND_PORT || 3001;
app.listen(PORT, 'localhost', () => console.log(`🚀 Backend server running on localhost:${PORT}`));