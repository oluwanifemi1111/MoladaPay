const express = require("express");
const router = express.Router();
const User = require("../models/User");
const { hashPin, verifyPin } = require("../utils/pin");

// ✅ Set PIN
router.post("/set", async (req, res) => {
  try {
    const { userId, pin } = req.body;
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found" });

    if (user.pin) return res.status(400).json({ message: "PIN already set" });

    user.pin = await hashPin(pin);
    await user.save();
    res.json({ success: true, message: "PIN set successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ✅ Change PIN
router.post("/change", async (req, res) => {
  try {
    const { userId, oldPin, newPin } = req.body;
    const user = await User.findById(userId);
    if (!user || !user.pin) return res.status(400).json({ message: "PIN not set" });

    const valid = await verifyPin(oldPin, user.pin);
    if (!valid) return res.status(401).json({ message: "Old PIN incorrect" });

    user.pin = await hashPin(newPin);
    await user.save();
    res.json({ success: true, message: "PIN changed successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ✅ Verify PIN
router.post("/verify", async (req, res) => {
  try {
    const { userId, pin } = req.body;
    const user = await User.findById(userId);
    if (!user || !user.pin) return res.status(400).json({ message: "PIN not set" });

    const valid = await verifyPin(pin, user.pin);
    if (!valid) return res.status(401).json({ success: false, message: "Invalid PIN" });

    res.json({ success: true, message: "PIN verified" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;