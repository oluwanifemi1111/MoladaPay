const express = require("express");
const router = express.Router();
const Flutterwave = require("flutterwave-node-v3");
const User = require("../models/User");
const authMiddleware = require("../middleware/auth");

const flw = new Flutterwave(process.env.FLW_PUBLIC_KEY, process.env.FLW_SECRET_KEY);

// ✅ Withdraw money (user → bank account)
router.post("/withdraw", authMiddleware, async (req, res) => {
  try {
    const { amount, account_number, bank_code, currency } = req.body;
    const user = req.user;

    if (user.balance < amount) {
      return res.status(400).json({ success: false, message: "Insufficient balance" });
    }

    // Debit wallet immediately
    user.balance -= amount;
    await user.save();

    const reference = `MOLADA-WITHDRAW-${Date.now()}-${user.id}`;

    const payload = {
      account_bank: bank_code, // e.g. "044" for Access Bank
      account_number,
      amount,
      currency: currency || "NGN",
      narration: "Molada Wallet Withdrawal",
      reference,
    };

    const response = await flw.Transfer.initiate(payload);

    if (response.status === "success") {
      return res.status(200).json({
        success: true,
        message: "Withdrawal initiated successfully",
        data: response.data,
        balance: user.balance,
      });
    } else {
      // Refund if failed
      user.balance += amount;
      await user.save();
      return res.status(400).json({ success: false, message: "Withdrawal failed" });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ success: false, message: "Withdrawal error" });
  }
});

module.exports = router;