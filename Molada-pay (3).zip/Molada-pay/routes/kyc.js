const express = require("express");
const router = express.Router();
const KYC = require("../models/KYC");
const User = require("../models/User");
const nodemailer = require("nodemailer");
const axios = require("axios");
const authMiddleware = require("../middleware/auth"); // protect routes

// ✅ Email transporter (Gmail/SMTP config)
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// ✅ Submit KYC (User uploads details → Flutterwave validation)
router.post("/submit", async (req, res) => {
  try {
    const { userId, fullName, dob, address, idType, idNumber, email } = req.body;

    let verificationStatus = "pending";
    let flutterwaveResponse = null;

    // 🔹 Call Flutterwave API depending on ID type
    if (idType === "BVN") {
      flutterwaveResponse = await axios.get(
        `https://api.flutterwave.com/v3/kyc/bvns/${idNumber}`,
        { headers: { Authorization: `Bearer ${process.env.FLW_SECRET_KEY}` } }
      );
    } else if (idType === "NIN") {
      flutterwaveResponse = await axios.post(
        "https://api.flutterwave.com/v3/kyc/nin",
        { nin: idNumber },
        { headers: { Authorization: `Bearer ${process.env.FLW_SECRET_KEY}` } }
      );
    }

    // 🔹 Decide status
    if (flutterwaveResponse && flutterwaveResponse.data.status === "success") {
      verificationStatus = "approved";
    } else {
      verificationStatus = "rejected";
    }

    // 🔹 Save KYC record
    const newKYC = new KYC({
      userId,
      fullName,
      dob,
      address,
      idType,
      idNumber,
      status: verificationStatus,
    });
    await newKYC.save();

    // 🔹 Send Email Notification
    const mailOptions = {
      from: `"Molada Pay" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: `KYC Verification - ${verificationStatus.toUpperCase()}`,
      text:
        verificationStatus === "approved"
          ? "🎉 Congratulations! Your KYC has been approved. You can now access all wallet features."
          : "❌ Sorry, your KYC verification failed. Please resubmit with valid details.",
    };
    await transporter.sendMail(mailOptions);

    res.status(200).json({ success: true, status: verificationStatus });
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ success: false, message: "KYC submission failed" });
  }
});

// ✅ Admin Review KYC (approve/reject manually)
router.post("/review/:kycId", authMiddleware, async (req, res) => {
  try {
    // Only admin can review
    if (req.user.role !== "admin") {
      return res.status(403).json({ success: false, message: "Access denied. Admin only." });
    }

    const { status, reason } = req.body; // "approved" or "rejected"
    const kycId = req.params.kycId;

    // Find KYC record
    const kyc = await KYC.findById(kycId).populate("userId");
    if (!kyc) {
      return res.status(404).json({ success: false, message: "KYC record not found" });
    }

    // Update status
    kyc.status = status;
    if (reason) kyc.reason = reason;
    await kyc.save();

    // If approved, mark user verified
    if (status === "approved") {
      kyc.userId.isVerified = true;
      await kyc.userId.save();
    }

    // Email notification
    let mailOptions = {
      from: `"Molada Pay" <${process.env.EMAIL_USER}>`,
      to: kyc.userId.email,
      subject: status === "approved" ? "KYC Verification Approved ✅" : "KYC Verification Rejected ❌",
      text:
        status === "approved"
          ? "Congratulations! Your KYC verification has been approved. You can now access full features of Molada Pay."
          : `Sorry, your KYC verification has been rejected. Reason: ${reason || "Not specified"}. Please re-submit.`,
    };
    await transporter.sendMail(mailOptions);

    res.json({ success: true, message: `KYC ${status} and email sent.` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

module.exports = router;