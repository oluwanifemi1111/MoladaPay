const express = require("express");
const router = express.Router();
const Flutterwave = require("flutterwave-node-v3");
const User = require("../models/User"); // your user schema
const authMiddleware = require("../middleware/authMiddleware"); // JWT middleware

// Load Flutterwave keys from env
const flw = new Flutterwave(process.env.FLW_PUBLIC_KEY, process.env.FLW_SECRET_KEY);

// ✅ Initialize deposit
router.post("/deposit", authMiddleware, async (req, res) => {
  try {
    const { amount, currency } = req.body;
    const user = req.user; // from middleware

    // Generate transaction reference
    const tx_ref = `MOLADA-${Date.now()}-${user.id}`;

    const payload = {
      tx_ref,
      amount,
      currency: currency || "NGN", // default NGN
      redirect_url: "http://localhost:5000/api/deposit/verify", // callback
      customer: {
        email: user.email,
        phonenumber: user.phone,
        name: user.username
      },
      customizations: {
        title: "Molada Pay Deposit",
        description: "Funding your Molada wallet",
        logo: "https://molada.com/logo.png" // replace with your logo
      }
    };

    const response = await flw.Payment.initialize(payload);

    return res.status(200).json({
      success: true,
      checkout_url: response.data.link
    });

  } catch (error) {
    console.error(error);
    return res.status(500).json({ success: false, message: "Deposit init failed" });
  }
});

// ✅ Verify transaction
router.get("/verify", async (req, res) => {
  try {
    const { transaction_id } = req.query;

    const response = await flw.Transaction.verify({ id: transaction_id });

    if (response.data.status === "successful") {
      // Find user by email
      const user = await User.findOne({ email: response.data.customer.email });
      if (!user) return res.status(404).json({ success: false, message: "User not found" });

      // Credit wallet balance
      user.balance += parseFloat(response.data.amount);
      await user.save();

      return res.status(200).json({
        success: true,
        message: "Deposit successful, wallet credited",
        balance: user.balance
      });
    } else {
      return res.status(400).json({ success: false, message: "Payment not successful" });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ success: false, message: "Verification failed" });
  }
});

module.exports = router;