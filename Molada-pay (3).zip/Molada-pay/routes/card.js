// backend/routes/card.js
const express = require("express");
const router = express.Router();
const Flutterwave = require("flutterwave-node-v3");
const nodemailer = require("nodemailer");

// Initialize Flutterwave SDK with your keys
const flw = new Flutterwave(process.env.FLW_PUBLIC_KEY, process.env.FLW_SECRET_KEY);

// Setup Nodemailer transporter
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER, // your sending email
    pass: process.env.EMAIL_PASS, // app password
  },
});

// Utility function to send styled email
async function sendPaymentEmail(to, subject, title, message, status) {
  const color = status === "success" ? "#6A0DAD" : "#D32F2F"; // purple for success, red for fail
  const buttonColor = status === "success" ? "#6A0DAD" : "#D32F2F";

  const html = `
  <div style="font-family: Arial, sans-serif; background: #f9f9f9; padding: 40px;">
    <div style="max-width: 600px; margin: auto; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
      <div style="background: ${color}; padding: 20px; text-align: center; color: white;">
        <h1 style="margin: 0; font-size: 24px;">Molada Pay</h1>
      </div>
      <div style="padding: 30px;">
        <h2 style="color: ${color}; margin-top: 0;">${title}</h2>
        <p style="font-size: 15px; line-height: 1.6; color: #444;">${message}</p>
        <div style="text-align: center; margin-top: 25px;">
          <a href="https://molada.com/dashboard" style="background: ${buttonColor}; color: white; text-decoration: none; padding: 12px 25px; border-radius: 8px; font-weight: bold;">Go to Dashboard</a>
        </div>
      </div>
      <div style="background: #f1f1f1; padding: 15px; text-align: center; font-size: 13px; color: #888;">
        © ${new Date().getFullYear()} Molada Pay. All rights reserved.
      </div>
    </div>
  </div>
  `;

  await transporter.sendMail({
    from: `"Molada Pay" <${process.env.EMAIL_USER}>`,
    to,
    subject,
    html,
  });
}

// Charge Card Route
router.post("/charge", async (req, res) => {
  try {
    const { card_number, cvv, expiry_month, expiry_year, currency, amount, email, fullname, tx_ref } = req.body;

    const payload = {
      card_number,
      cvv,
      expiry_month,
      expiry_year,
      currency,
      amount,
      email,
      fullname,
      tx_ref: tx_ref || "MC-" + Date.now(),
      enckey: process.env.FLW_ENCRYPTION_KEY, // Make sure this is in your .env
    };

    // Initiate Card Charge
    const response = await flw.Charge.card(payload);

    if (response.status === "success") {
      await sendPaymentEmail(
        email,
        "Molada Pay - Payment Successful",
        "Payment Successful 🎉",
        `Your card payment of ${currency} ${amount} has been processed successfully. Transaction Ref: ${payload.tx_ref}.`,
        "success"
      );
      return res.status(200).json({ success: true, data: response });
    } else {
      await sendPaymentEmail(
        email,
        "Molada Pay - Payment Failed",
        "Payment Failed ❌",
        `We were unable to process your card payment of ${currency} ${amount}. Please try again or use another method.`,
        "fail"
      );
      return res.status(400).json({ success: false, data: response });
    }
  } catch (error) {
    console.error(error);

    if (req.body?.email) {
      await sendPaymentEmail(
        req.body.email,
        "Molada Pay - Payment Error",
        "Payment Error ⚠️",
        "An unexpected error occurred while processing your card payment. Please try again later.",
        "fail"
      );
    }

    return res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;