const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Wallet = require('../models/Wallet');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid')
const mongoose = require('mongoose')
const generateFingerprint = require("../utils/fingerprint");
const geoip = require("geoip-lite");
const countryToCurrency = require("../utils/countryToCurrency");
const axios = require("axios");
const os = require("os");
const fetch = require("node-fetch");

// ===== EMAIL TRANSPORTER =====
const transporter = nodemailer.createTransport({
    service: process.env.EMAIL_SERVICE || 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

// ===== PROFESSIONAL EMAIL TEMPLATE (OTP) =====
function otpEmailTemplate(name, otp) {
    return `
    <div style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 30px;">
        <div style="max-width: 500px; margin: auto; background-color: white; padding: 20px; border-radius: 10px; border: 1px solid #ddd;">
            <div style="text-align: center; margin-bottom: 20px;">
                <img src="https://yourlogo-link.com/logo.png" alt="Molada Logo" style="height: 50px;">
            </div>
            <h2 style="color: #3b1a5b; text-align: center;">Verify Your Email</h2>
            <p>Hello <strong>${name}</strong>,</p>
            <p>Your One-Time Password (OTP) to verify your account is:</p>
            <div style="text-align: center; font-size: 24px; font-weight: bold; background: #3b1a5b; color: white; padding: 10px; border-radius: 5px;">
                ${otp}
            </div>
            <p>This code will expire in 10 minutes. If you didn’t request this, please ignore this email.</p>
            <p style="font-size: 12px; color: #999; text-align: center;">© ${new Date().getFullYear()} Molada. All rights reserved.</p>
        </div>
    </div>
    `;
}

// ===== PROFESSIONAL EMAIL TEMPLATE (RESET LINK) =====
function resetPasswordTemplate(name, link) {
    return `
    <div style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 30px;">
        <div style="max-width: 500px; margin: auto; background-color: white; padding: 20px; border-radius: 10px; border: 1px solid #ddd;">
            <div style="text-align: center; margin-bottom: 20px;">
                <img src="https://yourlogo-link.com/logo.png" alt="Molada Logo" style="height: 50px;">
            </div>
            <h2 style="color: #3b1a5b; text-align: center;">Password Reset Request</h2>
            <p>Hello <strong>${name}</strong>,</p>
            <p>You requested to reset your password. Click the button below to reset it:</p>
            <div style="text-align: center; margin: 20px 0;">
                <a href="${link}" style="background: #3b1a5b; color: white; padding: 12px 20px; text-decoration: none; border-radius: 5px;">Reset Password</a>
            </div>
            <p>This link will expire in 15 minutes. If you did not request this, please ignore this email.</p>
            <p style="font-size: 12px; color: #999; text-align: center;">© ${new Date().getFullYear()} Molada. All rights reserved.</p>
        </div>
    </div>
    `;
}

// ===== POLISHED PARENT NOTIFICATION EMAIL =====
function parentNotificationTemplate(childName, childAge) {
    return `
    <div style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 30px;">
        <div style="max-width: 500px; margin: auto; background-color: white; padding: 20px; border-radius: 10px; border: 1px solid #ddd;">
            <h2 style="color: #3b1a5b;">Your Child Has Registered on Molada Pay</h2>
            <p>Dear Parent/Guardian,</p>
            <p>This is to inform you that your child <strong>${childName}</strong>, aged <strong>${childAge}</strong>, has successfully registered for a Molada Pay account.</p>
            <p>Molada Pay is a secure wallet service that enables money transfers, online payments, and account management. We encourage parents to be aware of their child's activity.</p>
            <p>If you have any questions, please contact our support team at <a href="mailto:support@moladapay.com">support@moladapay.com</a>.</p>
            <p>Thank you,<br>Molada Pay Security Team</p>
            <p style="font-size: 12px; color: #999; text-align: center;">© ${new Date().getFullYear()} Molada. All rights reserved.</p>
        </div>
    </div>
    `;
}

// ===== NEW DEVICE LOGIN NOTIFICATION =====
function newDeviceLoginTemplate(name, ip, location, userAgent, time) {
    return `
    <div style="font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 30px;">
        <div style="max-width: 500px; margin: auto; background-color: #ffffff; padding: 20px; border-radius: 10px; border: 1px solid #eee;">
            <div style="text-align: center; margin-bottom: 20px;">
                <img src="https://yourlogo-link.com/logo.png" alt="Molada Logo" style="height: 50px;">
            </div>
            <h2 style="color: #3b1a5b; text-align: center;">New Login Detected</h2>
            <p>Hello <strong>${name}</strong>,</p>
            <p>We noticed a new login to your Molada Pay account:</p>
            <ul style="list-style: none; padding-left: 0;">
                <li><strong> Location:</strong> ${location || "Unknown"}</li>
                <li><strong> IP:</strong> ${ip}</li>
                <li><strong> Device:</strong> ${userAgent}</li>
                <li><strong> Time:</strong> ${time}</li>
            </ul>
            <p>If this was you, no further action is required.  
             If you did not log in, <span style="color: red;">please reset your password immediately</span> to secure your account.</p>
            <div style="text-align: center; margin: 20px 0;">
                <a href="https://moladapay.com/reset-password"            
                 style="background: #3b1a5b; color: white; padding: 12px 20px; text-decoration: none; border-radius: 5px;">
                    Reset Password
                </a>
            </div>
            <p style="font-size: 12px; color: #999; text-align: center;">© ${new Date().getFullYear()} Molada. All rights reserved.</p>
        </div>
    </div>
    `;
}

// Generate unique wallet ID function
function generateWalletId() {
    return `WAL-${uuidv4()}`;
}

const { detectCountryAndCurrency } = require("../utils/phoneUtils.js");

// ===== REGISTRATION =====
router.post('/register', async (req, res) => {
  try {
    const {
      fullName, address, postalCode, age, email, parentEmail,
      phone, referralCode, password, confirmPassword, country
    } = req.body;

    if (age < 3) {
      return res.status(400).json({ success: false, message: 'You must be at least 3 years old to register.' });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({ success: false, message: 'Passwords do not match.' });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ success: false, message: 'Email already registered.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const otp = crypto.randomInt(100000, 999999).toString();
    const walletId = generateWalletId();

    // Detect country + currency (from phone or provided country)
    const { country: detectedCountry, currency } = detectCountryAndCurrency(phone, country);

    const newUser = new User({
      fullName,
      address,
      postalCode,
      age,
      email,
      parentEmail: age < 18 ? parentEmail : null,
      phone,
      referralCode,
      password: hashedPassword,
      walletId,
      otp,
      otpExpiresAt: Date.now() + 10 * 60 * 1000,
      otpUsed: false,
      verified: false,
      country: detectedCountry,
      currency
    });

    const savedUser = await newUser.save();

    try {
      if (age < 18) {
        await transporter.sendMail({
          from: '"Molada" <nifemidavid11@gmail.com>',
          to: email,
          subject: 'Molada Email Verification',
          html: otpEmailTemplate(fullName, otp)
        });

        await transporter.sendMail({
          from: '"Molada" <nifemidavid11@gmail.com>',
          to: parentEmail,
          subject: 'Notification: Your Child Registered on Molada Pay',
          html: parentNotificationTemplate(fullName, age)
        });
      } else {
        await transporter.sendMail({
          from: '"Molada Pay" <nifemidavid11@gmail.com>',
          to: email,
          subject: 'Molada Email Verification',
          html: otpEmailTemplate(fullName, otp)
        });
      }
    } catch (emailErr) {
      await User.deleteOne({ _id: savedUser._id });
      console.error("Email sending failed:", emailErr);
      return res.status(500).json({ success: false, message: 'Failed to send email(s). Please try again.' });
    }

    res.status(201).json({
      success: true,
      message: 'User registered successfully. Relevant emails sent.',
      walletId,
      country: detectedCountry,
      currency
    });
  } catch (err) {
    console.error("Registration error:", err);
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
});

const cron = require('node-cron');

// Function to send warning email
async function sendVerificationWarningEmail(user) {
  const mailOptions = {
    from: `"Molada Pay" <${process.env.EMAIL_USER}>`,
    to: user.email,
    subject: " Action Required: Verify Your Molada Pay Account",
    html: `
      <div style="font-family: Arial, sans-serif; padding:20px; max-width:600px; margin:auto; border-radius:12px; background:#f9f9f9; border:1px solid #eee;">
        <div style="text-align:center; padding:10px;">
          <h1 style="color:#6c3fb0;">Molada Pay</h1>
        </div>
        <div style="background:#fff; padding:20px; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.05);">
          <h2 style="color:#6c3fb0;">Hi ${user.email},</h2>
          <p>We noticed you created a Molada Pay account but haven’t verified your email yet.</p>
          <p><b>Your account will be deleted in the next 30 minutes</b> if you don’t verify.</p>
          <p>Please verify now to enjoy secure payments, crypto, and more!</p>
          <a href="${process.env.FRONTEND_URL}/verify"
            style="display:inline-block; padding:12px 20px; margin-top:20px; background:#6c3fb0; color:#fff; text-decoration:none; border-radius:8px;">
            Verify Now
          </a>
        </div>
        <p style="font-size:12px; color:#999; text-align:center; margin-top:20px;">© ${new Date().getFullYear()} Molada Pay. All rights reserved.</p>
      </div>
    `,
  };
  try {
    await transporter.sendMail(mailOptions);
    console.log(` Warning email sent to ${user.email}`);
  } catch (error) {
    console.error(" Error sending warning email:", error);
  }
}
// CRON JOB: Runs every 5 minutes, checks unverified users
cron.schedule("*/5 * * * *", async () => {
  try {
    const now = new Date();

    // Find users who registered but not verified
    const unverifiedUsers = await User.find({ verified: false });

    for (let user of unverifiedUsers) {
      const createdAt = new Date(user.createdAt);
      const diffMinutes = Math.floor((now - createdAt) / (1000 * 60));

      // After 30 mins: send warning email if not already sent
      if (diffMinutes >= 30 && diffMinutes < 60 && !user.warningSent) {
        await sendVerificationWarningEmail(user);
        user.warningSent = true;
        await user.save();
      }

      // After 60 mins: auto delete account
      if (diffMinutes >= 60) {
        await User.deleteOne({ _id: user._id });
        console.log(` Deleted unverified account: ${user.email}`);
      }
    }
  } catch (error) {
    console.error(" Error in cron job:", error);
  }
});

// VERIFY OTP
router.post('/verify', async (req, res) => {
    try {
        const { email, otp } = req.body;
        const user = await User.findOne({ email });

        if (!user) return res.status(404).json({ success: false, message: 'User not found' });

        if (user.otp !== otp || user.otpUsed) {
            return res.status(400).json({ success: false, message: 'Invalid or already used OTP' });
        }

        if (user.otpExpiresAt < Date.now()) {
            return res.status(400).json({ success: false, message: 'OTP expired' });
        }

        // Mark OTP as used
        user.otp = undefined;
        user.verified = true;
        user.otpUsed = true;
        user.otpExpiresAt = undefined;

        // Check wallet
        let wallet = await Wallet.findOne({ user: user._id });
        if (!wallet) {
            wallet = new Wallet({
                user: user._id, // must be ObjectId
                balance: 0
            });

            await wallet.save().catch(err => {
                console.error("Wallet save failed:", err);
                throw err;
            });

            // link wallet to user (make sure User schema has wallet field!)
            user.wallet = wallet._id;
        }

        await user.save();

        console.log("✅ Wallet created/linked:", wallet);
        res.json({ success: true, message: 'OTP verified, wallet created', wallet });

    } catch (error) {
        console.error("❌ Verify OTP error:", error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

router.post('/resend-otp', async (req, res) => {
    try {
        const { email } = req.body;

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const now = new Date();

        // Reset counter if more than 1 hour passed
        if (user.otpLastRequest && now - user.otpLastRequest > 60 * 60 * 1000) {
            user.otpRequests = 0;
        }

        // Check limit
        if (user.otpRequests >= 3) {
            return res.status(429).json({
                success: false,
                message: 'Too many OTP requests. Please try again in 1 hour.'
            });
        }

        // Generate new OTP
        const otp = crypto.randomInt(100000, 999999).toString();
        user.otp = otp;
        user.otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 min expiry
        user.otpRequests += 1;
        user.otpLastRequest = now;

        await user.save();

         try {
            await transporter.sendMail({
                from: '"Molada Pay" <nifemidavid11@gmail.com>',
                to: email,
                subject: 'Molada Pay Email Verification',
                html: otpEmailTemplate(user.fullName, otp)
            });
        } catch (emailErr) {
            console.error("Email sending failed:", emailErr);
            return res.status(500).json({ success: false, message: 'Failed to send email. Please try again.' });
        }

        res.json({ success: true, message: 'OTP resent successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});
router.post('/resend-otp', async (req, res) => {
    try {
        const { email } = req.body;

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const now = new Date();

        // Reset counter if more than 1 hour passed
        if (user.otpLastRequest && now - user.otpLastRequest > 60 * 60 * 1000) {
            user.otpRequests = 0;
        }

        // Check limit
        if (user.otpRequests >= 3) {
            return res.status(429).json({
                success: false,
                message: 'Too many OTP requests. Please try again in 1 hour.'
            });
        }

        // Generate new OTP
        const otp = crypto.randomInt(100000, 999999).toString();
        user.otp = otp;
        user.otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 min expiry
        user.otpRequests += 1;
        user.otpLastRequest = now;

        await user.save();

         try {
            await transporter.sendMail({
                from: '"Molada Pay" <nifemidavid11@gmail.com>',
                to: email,
                subject: 'Molada Pay Email Verification',
                html: otpEmailTemplate(user.fullName, otp)
            });
        } catch (emailErr) {
            console.error("Email sending failed:", emailErr);
            return res.status(500).json({ success: false, message: 'Failed to send email. Please try again.' });
        }

        res.json({ success: true, message: 'OTP resent successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// ===== FORGOT PASSWORD =====
router.post('/forgot-password', async (req, res) => {
    try {
        const { email } = req.body;
        const user = await User.findOne({ email });
        if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

        const resetToken = crypto.randomBytes(32).toString('hex');
        const resetTokenHash = crypto.createHash('sha256').update(resetToken).digest('hex');
        user.resetPasswordToken = resetTokenHash;
        user.resetPasswordExpires = Date.now() + 15 * 60 * 1000; // 15 minutes
        await user.save();

        const resetLink = `http://localhost:5000/reset-password/${resetToken}`;

        await transporter.sendMail({
            from: '"Molada" <nifemidavid11@gmail.com>',
            to: user.email,
            subject: 'Molada Password Reset',
            html: resetPasswordTemplate(user.fullName, resetLink)
        });

        res.json({ success: true, message: 'Password reset link sent to email.' });

    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// ===== RESET PASSWORD =====
router.post('/reset-password/:token', async (req, res) => {
    try {
        const { password, confirmPassword } = req.body;
        if (password !== confirmPassword) {
            return res.status(400).json({ success: false, message: 'Passwords do not match.' });
        }

        const resetTokenHash = crypto.createHash('sha256').update(req.params.token).digest('hex');
        const user = await User.findOne({
            resetPasswordToken: resetTokenHash,
            resetPasswordExpires: { $gt: Date.now() }
        });

        if (!user) return res.status(400).json({ success: false, message: 'Invalid or expired token.' });

        user.password = await bcrypt.hash(password, 10);
        user.resetPasswordToken = null;
        user.resetPasswordExpires = null;
        await user.save();

        res.json({ success: true, message: 'Password reset successfully.' });

    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});


// =====================
// LOGIN ROUTE
// =====================
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if user exists
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    // Check if account is verified
    if (!user.verified) {
      return res.status(403).json({ success: false, message: "Account not verified. Please verify your OTP." });
    }

    // Validate password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ success: false, message: "Invalid credentials" });

    // Update last login timestamp
    user.lastLogin = new Date();

    // =========================
    // NEW DEVICE & LOCATION CHECK
    // =========================
    let ip = req.headers["x-forwarded-for"]?.split(",")[0] || req.connection.remoteAddress || "0.0.0.0";
    const userAgent = req.headers["user-agent"] || "unknown";
    const time = new Date().toLocaleString();

    // Get real location from ipapi.co
    let locationData = {};
    try {
      const response = await axios.get(`https://ipapi.co/${ip}/json/`);
      locationData = response.data;
    } catch (err) {
      console.error("Location fetch failed:", err.message);
      locationData = { city: "Unknown", region: "Unknown", country_name: "Unknown" };
    }

    // Generate fingerprint
    const fingerprint = generateFingerprint({
      ip,
      userAgent,
      os: os.platform() || "unknown",
    });

    // Ensure devices array exists
    if (!Array.isArray(user.devices)) user.devices = [];

    // Check if device already registered
    const deviceExists = user.devices.find((d) => d.fingerprint === fingerprint);

    if (!deviceExists) {
      user.devices.push({ fingerprint, ip, userAgent, createdAt: new Date() });
      await user.save();

      // Send new device login notification
      try {
        await transporter.sendMail({
          from: '"Molada Pay Security" <nifemidavid11@gmail.com>',
          to: user.email,
          subject: "New Device Login Detected",
          html: newDeviceLoginTemplate(
            user.fullName,
            ip,
            `${locationData.city}, ${locationData.region}, ${locationData.country_name}`,
            userAgent,
            time
          ),
        });
      } catch (mailErr) {
        console.error("Failed to send new device email:", mailErr.message);
      }
    }

    // =========================
    // STORE LOGIN HISTORY
    // =========================
    if (!Array.isArray(user.loginHistory)) user.loginHistory = [];

    user.loginHistory.push({
      ip,
      userAgent,
      city: locationData.city || "Unknown",
      region: locationData.region || "Unknown",
      country: locationData.country_name || "Unknown",
      org: locationData.org || "Unknown",
      timezone: locationData.timezone || "Unknown",
      loginAt: new Date(),
    });

    // Generate JWT token
    const token = jwt.sign(
      { id: user._id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    await user.save();

    res.status(200).json({
      success: true,
      message: "Login successful",
      token,
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        walletId: user.walletId,
        walletBalance: user.walletBalance,
        lastLogin: user.lastLogin,
        loginHistory: user.loginHistory,
      },
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// =====================
// LOGOUT ROUTE
// =====================
// 🚪 Logout Route (using devices array)
router.post("/logout", async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) {
      return res.status(400).json({ success: false, message: "No token provided" });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);

    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    // 🔹 Update latest device logoutAt
    if (user.devices.length > 0) {
      user.devices[user.devices.length - 1].logoutAt = new Date();
    }

    await user.save();

    return res.status(200).json({
      success: true,
      message: "Logged out successfully",
      redirect: "/api/auth/login"
    });
  } catch (err) {
    console.error("Logout error:", err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
});

// 👤 Get Profile
router.get("/profile", async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) {
      return res.status(400).json({ success: false, message: "No token provided" });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select("-password");

    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    return res.status(200).json({
      success: true,
      user,
    });
  } catch (err) {
    console.error("Profile error:", err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
});

// ✅ Set or update transaction PIN
router.post("/set-pin", async (req, res) => {
  try {
    const { userId, pin } = req.body;
    if (!pin || pin.length < 4) {
      return res.status(400).json({ success: false, message: "PIN must be at least 4 digits" });
    }

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    const salt = await bcrypt.genSalt(10);
    user.transactionPin = await bcrypt.hash(pin, salt);
    await user.save();

    res.json({ success: true, message: "Transaction PIN set successfully" });
  } catch (err) {
    console.error("Set PIN Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

router.post("/set-fingerprint", async (req, res) => {
  try {
    const { userId, fingerprint } = req.body;

    if (!userId || !fingerprint) {
      return res.status(400).json({ success: false, message: "User ID and fingerprint are required" });
    }

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    user.fingerprint = fingerprint; // Just store as a string/token
    await user.save();

    res.json({ success: true, message: "Fingerprint set/updated successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: "Server error", error: err.message });
  }
});


module.exports = router; // ✅ Important!