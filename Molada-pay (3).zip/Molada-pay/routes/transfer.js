// routes/transfer.js
const express = require("express");
const QRCode = require("qrcode");
const nodemailer = require("nodemailer");
const cron = require("node-cron");
const router = express.Router();

const User = require("../models/User");
const Transaction = require("../models/Transaction");
const { convertCurrency } = require("../utils/exchangeRates");
const authMiddleware = require("../middleware/authMiddleware");
const checkKyc = require("../middleware/checkKyc");

// ===== EMAIL TRANSPORTER =====
const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE || 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  },
});

// ===== EMAIL SENDER (modern template) =====
const sendEmail = async ({ to, subject, name, type, amount, balance, currency = "USD", html }) => {
  const fmt = (n) => Number(n).toLocaleString(undefined, { maximumFractionDigits: 2 });

  const defaultHtml = `
  <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border-radius: 12px; background:#f7f9fc; color:#111;">
    <h2 style="color:#4B0082; text-align:center; margin:0 0 16px;">Molada Pay</h2>
    <div style="background:#fff; padding:20px; border-radius:12px; box-shadow:0 4px 12px rgba(0,0,0,.06);">
      <p style="margin:0 0 12px; font-size:16px;">Hello <b>${name}</b>,</p>
      <p style="margin:0 0 12px;">You have a new <b>${type}</b> transaction.</p>
      <p style="margin:0 0 6px;"><b>Amount:</b> ${currency} ${fmt(amount)}</p>
      <p style="margin:0 0 6px;"><b>Current Balance:</b> ${currency} ${fmt(balance)}</p>
      <p style="margin:16px 0 0;">Thanks for using <b>Molada Pay</b>.</p>
    </div>
    <div style="text-align:center; font-size:12px; margin-top:12px; color:#777;">
      &copy; ${new Date().getFullYear()} Molada. All rights reserved.
    </div>
  </div>
  `;

  await transporter.sendMail({
    from: `"Molada Pay" <${"nifemidavid11@gmail.com"}>`,
    to,
    subject,
    html: html || defaultHtml,
  });
};

// =================== QR CODE (receive funds) ===================
router.get("/generate-qr/:userId", async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    const qrData = { email: user.email, phone: user.phone, name: user.fullName };
    const qrCodeUrl = await QRCode.toDataURL(JSON.stringify(qrData));

    res.json({ success: true, qrCodeUrl });
  } catch (err) {
    console.error("QR Generate Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// =================== PREVIEW (rates + fee) ===================
router.post("/preview", async (req, res) => {
  try {
    const { senderId, receiverIdentifier, receiverQrData, amount } = req.body;

    const amt = Number(amount);
    if (!senderId || !amount || isNaN(amt) || amt <= 0) {
      return res.status(400).json({ success: false, message: "Invalid or missing amount/sender" });
    }

    const sender = await User.findById(senderId);
    if (!sender) return res.status(404).json({ success: false, message: "Sender not found" });

    let receiver;
    if (receiverQrData) {
      const parsed = JSON.parse(receiverQrData);
      receiver = await User.findOne({ $or: [{ email: parsed.email }, { phone: parsed.phone }] });
    } else {
      receiver = await User.findOne({ $or: [{ email: receiverIdentifier }, { phone: receiverIdentifier }] });
    }
    if (!receiver) return res.status(404).json({ success: false, message: "Receiver not found" });

    const senderCurrency = sender.currency || "USD";
    const receiverCurrency = receiver.currency || "USD";

    let convertedAmount = amt;
    let fee = 0;
    if (senderCurrency !== receiverCurrency) {
      convertedAmount = await convertCurrency(senderCurrency, receiverCurrency, amt);
      fee = Number((amt * 0.02).toFixed(2)); // 2% fee
    }

    res.json({
      success: true,
      preview: {
        from: senderCurrency,
        to: receiverCurrency,
        originalAmount: amt,
        convertedAmount,
        fee,
        receiver: { name: receiver.fullName, email: receiver.email, phone: receiver.phone },
      },
    });
  } catch (err) {
    console.error("Preview Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// =================== SEND (Molada → Molada) ===================
router.post("/send", authMiddleware, checkKyc, async (req, res) => {
  try {
    const { senderId, receiverIdentifier, receiverQrData, amount, pin, fingerprint } = req.body;

    // Basic validation
    const amt = Number(amount);
    if (!senderId || !pin || !amount || isNaN(amt) || amt <= 0) {
      return res.status(400).json({ success: false, message: "Sender, valid amount and PIN are required" });
    }

    // Fetch sender
    const sender = await User.findById(senderId);
    if (!sender) return res.status(404).json({ success: false, message: "Sender not found" });

    // Require PIN always
    if (!sender.transactionPin) {
      return res.status(400).json({ success: false, message: "You must set up a transaction PIN before sending money." });
    }
    const isValidPin = await sender.comparePin(pin);
    if (!isValidPin) {
      return res.status(401).json({ success: false, message: "Invalid transaction PIN" });
    }

    // Fingerprint optional
    if (fingerprint) {
      if (!sender.fingerprint || fingerprint !== sender.fingerprint) {
        return res.status(401).json({ success: false, message: "Invalid fingerprint" });
      }
    }

    // Find receiver
    let receiver;
    if (receiverQrData) {
      const parsed = JSON.parse(receiverQrData);
      receiver = await User.findOne({ $or: [{ email: parsed.email }, { phone: parsed.phone }] });
    } else {
      receiver = await User.findOne({ $or: [{ email: receiverIdentifier }, { phone: receiverIdentifier }] });
    }
    if (!receiver) return res.status(404).json({ success: false, message: "Receiver not found" });

    // Block self-transfer
    if (sender._id.toString() === receiver._id.toString() || sender.email === receiver.email) {
      return res.status(400).json({ success: false, message: "You cannot send money to yourself." });
    }

    // Currency + fee
    const senderCurrency = sender.currency || "USD";
    const receiverCurrency = receiver.currency || "USD";

    let convertedAmount = amt;
    let fee = 0;
    if (senderCurrency !== receiverCurrency) {
      convertedAmount = await convertCurrency(senderCurrency, receiverCurrency, amt);
      fee = Number((amt * 0.02).toFixed(2));
    }

    // Balance check
    const totalDebit = amt + fee;
    if (Number(sender.walletBalance || 0) < totalDebit) {
      return res.status(400).json({
        success: false,
        message: `Insufficient funds. Balance: ${senderCurrency} ${Number(sender.walletBalance).toFixed(2)} | Required: ${senderCurrency} ${totalDebit.toFixed(2)}`
      });
    }

    // Update balances
    sender.walletBalance -= totalDebit;
    receiver.walletBalance += Number(convertedAmount);
    await sender.save();
    await receiver.save();
    const transferMethod = receiverQrData ? "qrcode" : "email/phone"

    // Save transaction
const tx = new Transaction({
  senderId: sender._id,
  receiverId: receiver._id,
  amount: amt,
  senderCurrency: senderCurrency,
  receiverCurrency: receiverCurrency,
  convertedAmount: convertedAmount, // after conversion if any
  fee: fee, // you can calculate fee earlier
  type: "transfer", // or "molada-to-molada" depending
  method: transferMethod, // "qrcode" or "email/phone"
  status: "success"
});

await tx.save();
    
    // Emails
    await sendEmail({
      to: sender.email,
      subject: "Money Sent - Molada Pay",
      name: sender.fullName,
      type: "Debit",
      amount: totalDebit,
      balance: sender.walletBalance,
      currency: senderCurrency,
    });

    await sendEmail({
      to: receiver.email,
      subject: "Money Received - Molada Pay",
      name: receiver.fullName,
      type: "Credit",
      amount: convertedAmount,
      balance: receiver.walletBalance,
      currency: receiverCurrency,
    });

    return res.json({ success: true, message: "Transfer successful", transaction: tx });
  } catch (err) {
    console.error("Send Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// =================== TRANSACTION HISTORY ===================
router.get("/history/:userId", authMiddleware, async (req, res) => {
  try {
    const { userId } = req.params;
    
    // Security: Ensure user can only access their own history (or admin access)
    if (req.user.id !== userId) {
      return res.status(403).json({ success: false, message: "Access denied. You can only view your own transaction history." });
    }

    const history = await Transaction.find({
      $or: [
        { senderId: userId }, 
        { receiverId: userId },
        { userId: userId }  // Include crypto transactions (deposits, withdrawals, swaps)
      ],
    })
      .populate("senderId", "fullName email")
      .populate("receiverId", "fullName email")
      .populate("userId", "fullName email")  // Populate userId field for crypto transactions
      .sort({ createdAt: -1 });

    res.json({ success: true, history });
  } catch (err) {
    console.error("History Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// =================== WEEKLY EMAIL CRON ===================
// Runs every Sunday 8AM
cron.schedule("0 8 * * 0", async () => {
  try {
    console.log(" Sending weekly reports...");

    const users = await User.find();
    for (let user of users) {
      const transactions = await Transaction.find({
        $or: [{ senderId: user._id }, { receiverId: user._id }],
      })
        .populate("senderId", "fullName email")
        .populate("receiverId", "fullName email")
        .sort({ createdAt: -1 })
        .limit(10);

      let historyHTML = transactions.map(
        (tx) => `
          <tr>
            <td>${tx.type}</td>
            <td>${tx.amount} ${tx.currency}</td>
            <td>${tx.status}</td>
            <td>${tx.createdAt.toDateString()}</td>
          </tr>
        `
      ).join("");

      const html = `
        <h2 style="color:#4B0082;">Molada Weekly Report</h2>
        <p>Hello ${user.fullName},</p>
        <p>Here is your weekly account summary:</p>
        <p><strong>Balance:</strong> ${user.walletBalance} ${user.currency || "USD"}</p>
        <h3>Recent Transactions</h3>
        <table border="1" cellspacing="0" cellpadding="8" style="border-collapse:collapse;">
          <thead style="background:#f0f0f0;">
            <tr><th>Type</th><th>Amount</th><th>Status</th><th>Date</th></tr>
          </thead>
          <tbody>${historyHTML || "<tr><td colspan='4'>No transactions</td></tr>"}</tbody>
        </table>
        <p>Thank you for banking with Molada </p>
      `;

      await sendEmail({
        to: user.email,
        subject: "Your Weekly Molada Report",
        name: user.fullName,
        balance: user.walletBalance,
        html,
      });
    }

    console.log(" Weekly reports sent");
  } catch (err) {
    console.error("Weekly report error:", err);
  }
});

module.exports = router;