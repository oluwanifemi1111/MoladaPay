const express = require("express");
const router = express.Router();
const axios = require("axios");
const Transaction = require("../models/Transaction");
const User = require("../models/User");

// Flutterwave secret key
const FLW_SECRET_KEY = process.env.FLW_SECRET_KEY;

/**
 * Generate Virtual Account Number for User
 */
router.post("/deposit/account", async (req, res) => {
  try {
    const { userId, bvn, email, phone, firstname, lastname, amount } = req.body;

    if (!amount || amount < 1) {
      return res.status(400).json({
        success: false,
        message: "Invalid amount"
      });
    }

    const response = await axios.post(
      "https://api.flutterwave.com/v3/virtual-account-numbers",
      {
        email,
        bvn, // optional, can be skipped
        phone,
        firstname,
        lastname,
        narration: "Molada Wallet Deposit",
        amount,
      },
      {
        headers: {
          Authorization: `Bearer ${FLW_SECRET_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    const accountData = response.data.data;

    // Save to user profile
    await User.findByIdAndUpdate(userId, {
      virtualAccount: {
        accountNumber: accountData.account_number,
        bankName: accountData.bank_name,
      },
    });

    res.json({
      success: true,
      message: "Virtual account generated successfully",
      account: {
        accountNumber: accountData.account_number,
        bankName: accountData.bank_name,
      },
    });
  } catch (err) {
    console.error("Error creating virtual account:", err.response?.data || err);
    res.status(500).json({
      success: false,
      message: "Failed to generate account",
    });
  }
});

/**
 * Webhook to handle Flutterwave deposit & withdrawal events
 */
router.post("/webhook/flutterwave", async (req, res) => {
  try {
    const event = req.body;

    // Verify webhook signature
    const crypto = require("crypto");
    const hash = crypto
      .createHmac("sha256", FLW_SECRET_KEY)
      .update(JSON.stringify(req.body))
      .digest("hex");

    if (req.headers["verif-hash"] !== hash) {
      return res.status(401).json({ success: false, message: "Invalid signature" });
    }

    const { status, tx_ref, customer, amount, currency } = event.data;

    // Find user by email (or other identifier)
    const user = await User.findOne({ email: customer.email });
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    let transactionStatus = "pending";
    if (status === "successful") transactionStatus = "success";
    else if (status === "failed") transactionStatus = "failed";
    else if (status === "cancelled") transactionStatus = "cancelled";

    // Update wallet balance if deposit was successful
    if (transactionStatus === "success" && event.data.type === "deposit") {
      user.walletBalance += amount;
      await user.save();
    }

    // Record in transaction history (Molada unified)
    const transaction = new Transaction({
      userId: user._id,
      type: event.data.type || "external",
      amount,
      currency,
      status: transactionStatus,
      reference: tx_ref,
      source: "external", // external deposit/withdraw
      date: new Date(),
    });
    await transaction.save();

    res.json({ success: true });
  } catch (err) {
    console.error("Webhook error:", err);
    res.status(500).json({ success: false });
  }
});

module.exports = router;