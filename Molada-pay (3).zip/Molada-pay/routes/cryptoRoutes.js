// routes/cryptoRoutes.js
const express = require("express");
const router = express.Router();
const User = require("../models/User");
const authMiddleware = require("../middleware/authMiddleware");
// import wallet services
const { generateAddress } = require("../services/walletServices");
const walletServices = require("../services/walletServices");
// ✅ Generate new wallet address for a chain
// ✅ Generate address for a chain
// ✅ Generate or fetch crypto address
router.post("/generate", authMiddleware, async (req, res) => {
  try {
    const { chain } = req.body;
    const userId = req.user.id;

    if (!chain) {
      return res.status(400).json({ error: "Chain is required (bitcoin | ethereum | tron)" });
    }

    const wallet = await generateAddress(userId, chain);
    return res.json({
      success: true,
      message: `${chain} address ready`,
      wallet,
    });
  } catch (err) {
    console.error("Error generating address:", err);
    res.status(500).json({ error: err.message });
  }
});

// ✅ Get all saved crypto addresses
router.get("/wallets", authMiddleware, async (req, res) => {
  try {
    const user = req.user;
    if (!user || !user.crypto) {
      return res.status(404).json({ error: "No wallets found" });
    }

    return res.json({
      success: true,
      wallets: {
        bitcoin: user.crypto.bitcoin,
        ethereum: user.crypto.ethereum,
        tron: user.crypto.tron,
      },
    });
  } catch (err) {
    console.error("Error fetching wallets:", err);
    res.status(500).json({ error: err.message });
  }
});
// GET BALANCES
router.get('/balance/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const balances = {};

    // ---- BITCOIN ----
    if (user.crypto.bitcoin) {
      try {
        const btcBalance = await walletServices.getBTCBalance(user.crypto.bitcoin);
        balances.bitcoin = { address: user.crypto.bitcoin, balance: btcBalance };
      } catch (err) {
        balances.bitcoin = { address: user.crypto.bitcoin, error: err.message };
      }
    }

    // ---- ETHEREUM ----
    if (user.crypto.ethereum) {
      try {
        const ethBalance = await walletServices.getETHBalance(user.crypto.ethereum);
        balances.ethereum = { address: user.crypto.ethereum, balance: ethBalance };

        // USDT (ERC20)
        const usdtEthBalance = await walletServices.getUsdtErc20Balance(user.crypto.ethereum);
        balances.usdt_eth = { address: user.crypto.ethereum, balance: usdtEthBalance };
      } catch (err) {
        balances.ethereum = { address: user.crypto.ethereum, error: err.message };
        balances.usdt_eth = { address: user.crypto.ethereum, error: err.message };
      }
    }

    // ---- TRON ----
if (user.crypto.tron) {
  // TRX
  try {
    const trxBalance = await walletServices.getTRXBalance(user.crypto.tron);
    balances.tron = { address: user.crypto.tron, balance: trxBalance };
  } catch (err) {
    balances.tron = { address: user.crypto.tron, error: err.message };
  }

  // USDT TRC20
  try {
    const usdtTrc20Balance = await walletServices.getUsdtTrc20Balance(user.crypto.tron);
    balances.usdt_trc20 = { address: user.crypto.tron, balance: usdtTrc20Balance };
  } catch (err) {
    balances.usdt_trc20 = { address: user.crypto.tron, error: err.message };
  }
}
    return res.json({ success: true, balances });
  } catch (err) {
    console.error("Balance error:", err);
    return res.status(500).json({ success: false, error: err.message });
  }
}); // closes router.get('/balance/:userId', ...)
// Send crypto (auto-detect chain if needed)
// POST /api/crypto/send
router.post("/send", authMiddleware, async (req, res) => {
  try {
    const { symbol, to, amount, chain: providedChain } = req.body;
    if (!symbol || !to || !amount) {
      return res.status(400).json({ error: "symbol, to and amount required" });
    }

    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ error: "User not found" });

    // detect chain if not provided
    const chain = providedChain || walletServices.detectChain(to);

    // pick private key for the chain from user.crypto
    let fromPrivKey;
    if (chain === "ethereum" || chain === "eth") fromPrivKey = user.crypto?.ethereumPrivateKey || user.crypto?.ethPrivateKey;
    if (chain === "tron") fromPrivKey = user.crypto?.tronPrivateKey || user.crypto?.trxPrivateKey;
    if (chain === "bitcoin" || chain === "btc") fromPrivKey = user.crypto?.bitcoinPrivateKey || user.crypto?.btcPrivateKey;

    if (!fromPrivKey) return res.status(400).json({ error: `User missing ${chain} private key` });

    // optional: check DB balance first (if you track balances in user.balances)
    const balanceFieldMap = {
      ethereum: "eth",
      eth: "eth",
      tron: "trx",
      bitcoin: "btc",
      btc: "btc",
    };
    const balField = balanceFieldMap[chain] || null;
    const currentBalance = balField ? (user.balances?.[balField] || 0) : null;
    if (currentBalance != null && Number(currentBalance) < Number(amount)) {
      return res.status(400).json({ error: `Insufficient ${balField} balance. Local: ${currentBalance}, required: ${amount}` });
    }

    // call send
    const result = await walletServices.sendCrypto({
      chain,
      symbol,
      to,
      amount,
      fromPrivKey,
    });

    // normalize txid
    const txid = result?.txid || result?.hash || result?.txHash || (result?.raw && result.raw.transactionHash) || null;
    console.log(`[SENT] user=${user.email} chain=${chain} symbol=${symbol} amount=${amount} to=${to} txid=${txid}`);

    // update sender local balances (best-effort)
    if (balField) {
      if (!user.balances) user.balances = {};
      user.balances[balField] = Math.max(0, (user.balances[balField] || 0) - Number(amount));
      await user.save();
    }

    // create withdraw Transaction record for sender
    const Transaction = require("../models/Transaction");
    const withdrawTx = new Transaction({
      userId: user._id,
      amount: Number(amount),
      currency: symbol.toLowerCase(),
      type: "withdraw",
      method: "blockchain",
      status: "pending",
      onchainTxHash: txid
    });
    await withdrawTx.save();

    // Normalize chain aliases to canonical values
    const normalizeChain = (chain) => {
      const chainMap = {
        'eth': 'ethereum',
        'ethereum': 'ethereum',
        'trx': 'tron', 
        'tron': 'tron',
        'btc': 'bitcoin',
        'bitcoin': 'bitcoin'
      };
      return chainMap[chain.toLowerCase()] || null;
    };

    // If recipient is an internal user, credit them
    const normalizedChain = normalizeChain(chain);
    let recipient = null;
    
    if (normalizedChain) {
      const recipientQueryFields = {
        ethereum: { "crypto.ethereum": to },
        tron: { "crypto.tron": to },
        bitcoin: { "crypto.bitcoin": to },
      };
      recipient = await User.findOne(recipientQueryFields[normalizedChain]);
    }
    if (recipient) {
      // credit their local balance
      const recipientBalanceKey = balanceFieldMap[chain] || null;
      if (!recipient.balances) recipient.balances = {};
      if (recipientBalanceKey) recipient.balances[recipientBalanceKey] = (recipient.balances[recipientBalanceKey] || 0) + Number(amount);
      await recipient.save();

      // create a deposit transaction for them (no onchainTxHash to avoid unique index collision)
      await Transaction.create({
        userId: recipient._id,
        amount: Number(amount),
        currency: symbol.toLowerCase(),
        type: "deposit",
        method: "blockchain",
        status: "success"
        // Note: omitting onchainTxHash to avoid unique index collision with withdraw transaction
      });
      console.log(`[CREDITED] internal recipient ${recipient.email} +${amount} ${symbol}`);
    }

    return res.json({ success: true, chain, txid, raw: result.raw || null });
  } catch (err) {
    console.error("Send error:", err);
    return res.status(500).json({ error: err.message || String(err) });
  }
});

// Swap (stub -> returns swapCrypto result)
// POST /api/crypto/swap
router.post("/swap", authMiddleware, async (req, res) => {
  try {
    const { chain, fromSymbol, toSymbol, amount, slippageBps } = req.body;
    if (!chain || !fromSymbol || !toSymbol || !amount) {
      return res.status(400).json({ error: "chain, fromSymbol, toSymbol, amount required" });
    }

    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ error: "User not found" });

    // choose private key depending on chain
    let fromPrivKey;
    if (chain.toLowerCase() === "ethereum") fromPrivKey = user.crypto?.ethereumPrivateKey || user.crypto?.ethPrivateKey;
    if (chain.toLowerCase() === "tron") fromPrivKey = user.crypto?.tronPrivateKey || user.crypto?.trxPrivateKey;

    if (!fromPrivKey) {
      return res.status(400).json({ error: `User missing ${chain} private key` });
    }

    // perform swap
    const result = await walletServices.swapCrypto({
      chain,
      fromSymbol,
      toSymbol,
      amount,
      slippageBps: slippageBps || 50,
      fromPrivKey,
    });

    // Log transaction record if needed
    const Transaction = require("../models/Transaction");
    await Transaction.create({
      userId: user._id,
      amount,
      currency: `${fromSymbol}->${toSymbol}`,
      type: "transfer",  // Using transfer since swap isn't in allowed enum
      method: "blockchain",
      status: "success",
      onchainTxHash: result.hash || result.txid || null
    });

    return res.json({ success: true, swap: result });
  } catch (err) {
    console.error("Swap error:", err);
    return res.status(500).json({ error: err.message || String(err) });
  }
});

    
module.exports = router;
