const express = require("express");
const { v4: uuidv4 } = require("uuid");
const { aiBotAnswer, sendSupportMail } = require("../services/supportService");

const router = express.Router();

/**
 * Live chat endpoint (AI → fallback to human)
 */
router.post("/chat", async (req, res) => {
  try {
    const { userEmail, message } = req.body;

    // Try AI bot
    const aiResponse = aiBotAnswer(message);
    if (aiResponse) {
      return res.json({ from: "bot", reply: aiResponse });
    }

    // Fallback → queue human support
    const ticketId = uuidv4().slice(0, 8);
    const queueNumber = Math.floor(Math.random() * 10) + 1;

    await sendSupportMail({
      userEmail,
      subject: "Molada Support Request",
      message,
      ticketId,
    });

    res.json({
      from: "system",
      reply: `Your query has been escalated to human support. You are number ${queueNumber} in queue.`,
      ticketId,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;