const express = require("express");
const router = express.Router();
const crypto = require("crypto");
const User = require("../models/User");
const Transaction = require("../models/Transaction");

// Flutterwave Webhook
router.post("/webhook", async (req, res) => {
  try {
    const secretHash = process.env.FLW_SECRET_HASH; // From Flutterwave dashboard
    const signature = req.headers["verif-hash"];

    // Verify signature
    if (!signature || signature !== secretHash) {
      return res.status(401).send("Invalid signature");
    }

    const event = req.body;
    console.log(" Webhook Event:", event);

    // Only handle successful transactions
    if (event.event === "charge.completed" && event.data.status === "successful") {
      const amount = event.data.amount;
      const currency = event.data.currency;
      const customerEmail = event.data.customer.email;
      const txRef = event.data.tx_ref;

      // Find user by email
      const user = await User.findOne({ email: customerEmail });
      if (!user) {
        console.log(" User not found for email:", customerEmail);
        return res.status(200).send("User not found, ignored");
      }

      // Save transaction
      const newTx = new Transaction({
        senderId: null,
        receiverId: user._id,
        amount: amount,
        senderCurrency: currency,
        receiverCurrency: user.currency || currency,
        convertedAmount: amount,
        fee: 0,
        type: "fund",
        method: "flutterwave",
        status: "completed",
      });
      await newTx.save();

      // Update user balance
      user.balance = (user.balance || 0) + amount;
      await user.save();

      // Alert system
      console.log(` Deposit Alert: ${user.email} funded ₦${amount}`);
      // Example: Email/SMS (for now just log)
      // sendEmail(user.email, "Deposit Successful", `Your account has been credited with ₦${amount}`);
      // sendPushNotification(user._id, `You have received ₦${amount}`);

      res.status(200).send("Webhook processed successfully");
    } else {
      res.status(200).send("Event ignored");
    }
  } catch (error) {
    console.error("Webhook Error:", error);
    res.status(500).send("Webhook processing failed");
  }
});

module.exports = router;