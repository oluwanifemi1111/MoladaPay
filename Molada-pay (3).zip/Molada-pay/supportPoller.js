const { listReplies, getReply } = require("./services/supportService");
const WebSocket = require("ws");

const wss = new WebSocket.Server({ port: 4001 });

async function pollSupport() {
  try {
    const messages = await listReplies();
    for (const msg of messages) {
      const text = await getReply(msg.id);

      // Broadcast to all clients
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({ from: "support", reply: text }));
        }
      });
    }
  } catch (err) {
    console.error("Poller error:", err.message);
  }
}

setInterval(pollSupport, 60000); // every 60s
console.log("Support poller running, WebSocket on :4001");